function [x, name, ufid]  = CramersRule(A, b)
    % Purpose: (COMMENT)
    % Input Argument [A]: (COMMENT)
    % Input Argument [b]: (COMMENT)
    % Output Argument [x]: (COMMENT)

    % --- Name & UFID --- %
    name = "First Last";
    ufid = 12345678;

    [m, n] = size(A); % # of rows and columns of A, respectively

    % Use CramersRule3x3.m as a guide to write this new function.
    % Hint: Use a for-loop.

    
end
