function [name, ufid, ...
    A1, b1, sol_1_partic, sol_1_matlab, sol_1_cramer, ...
    A2, b2, sol_2_partic, sol_2_matlab, sol_2_cramer, ...
    A3, b3, sol_3_partic, sol_3_matlab, sol_3_cramer] = Exercise2()
    % --- Name & UFID --- %
    name = "First Last";
    ufid = 12345678;

    % --- Part A (see CramersRule.m) [10 Points] --- %

    % --- Part B [10 Points] --- %
    % (i) m > n
    A1 = NaN;
    b1 = NaN;

    sol_1_partic = NaN;
    sol_1_matlab = NaN;
    sol_1_cramer = NaN;

    % (ii) m < n
    A2 = NaN;
    b2 = NaN;

    sol_2_partic = NaN;
    sol_2_matlab = NaN;
    sol_2_cramer = NaN;

    % (iii) m = n
    A3 = NaN;
    b3 = NaN;

    sol_3_partic = NaN;
    sol_3_matlab = NaN;
    sol_3_cramer = NaN;

    % --- Part C [10 Points] --- %

    %{ 
    When A is invertible, (OBSERVATIONS)

    When Ax = b is consistent where A is an n x n singular matrix,
    (OBSERVATIONS)

    When Ax = b is consistent where A is an m x n (non-square) matrix,
    (OBSERVATIONS)
    %}
end
